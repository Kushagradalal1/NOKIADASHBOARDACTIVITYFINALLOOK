package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
@RestController
public class Main {

    public static void main(String[] args) {
        SpringApplication.run(ShellScriptToJsonApplication.class, args);
    }

    @GetMapping("/getReport")
    public List<Report> getReport() {
        List<Report> reports = new ArrayList<>();
        try {
            // Run the shell script and capture the output
            Process process = Runtime.getRuntime().exec("/bin/sh C:\\Users\\kdalal\\Desktop\\WebDev\\index1.sh");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                // Parse the output and convert to Report objects
                String[] parts = line.split("\t");
                if (parts.length == 5) {
                    String fs = parts[0].trim();
                    String size = parts[1].trim();
                    String perc = parts[2].trim();
                    String mount = parts[3].trim();
                    Report report = new Report(fs, size, perc, mount);
                    reports.add(report);
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reports;
    }

    // Report class to represent the data in JSON format
    static class Report {
        private String fs;
        private String size;
        private String perc;
        private String mount;

        public Report(String fs, String size, String perc, String mount) {
            this.fs = fs;
            this.size = size;
            this.perc = perc;
            this.mount = mount;
        }

        // Getters and Setters
    }
}
