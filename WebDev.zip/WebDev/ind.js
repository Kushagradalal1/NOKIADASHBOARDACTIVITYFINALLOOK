const { exec } = require('child_process');
const express = require('express');


const app = express();
const port = 3000; // Replace with the desired port number

app.get('/json', (req, res) => {
  // Execute the shell script
  exec(`cmd.exe /c ${'C:\\Users\\kdalal\\Desktop\\WebDev\\index1.sh'}`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error executing shell script: ${error.message}`);
      return res.status(500).send('Internal Server Error');
    }
    if (stderr) {
      console.error(`Shell script returned an error: ${stderr}`);
      return res.status(500).send('Internal Server Error');
    }

    // Parse the shell script output and convert it into JSON format
    const jsonData = [];
    const lines = stdout.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const columns = lines[i].split('\t');
      if (columns.length === 4) { // Assuming there are 4 columns in each line
        const row = {
          FS: columns[0],
          SIZE: columns[1],
          USED: columns[2],
          FREE: columns[3]
        };
        jsonData.push(row);
      }
    }

    // Convert JSON data to a string
    const jsonString = JSON.stringify(jsonData, null, 2);

    // Send the JSON response
    res.setHeader('Content-Type', 'application/json');
    res.send(jsonString);
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
