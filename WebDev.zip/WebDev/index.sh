#!/bin/bash
echo "Filesystem       Size  Used Avail Use% Mounted on"
echo "devtmpfs          20G  4.0K  20G   1% /dev"
echo "bhlinn12.apac.nsn-net.net:/vol/bhlinn12_bin/linsee   50T   47T  2.2T  96% /tmp_opt"
echo "bhlinn61.apac.nsn-net.net:/vol/bhlinn61_bin3/ltesdkroot/ltesdkroot   30T   26T  4.3T  86% /build/ltesdkroot"
echo "/dev/mapper/vg00-lvol5   7.8G   19M  7.4G   1% /tmp"
echo "bheesn60:/bheesn60_MN5G/work_5g_BGL/L1_Loki   3.1T  1.1T  2.0T  37% /common_storage"
