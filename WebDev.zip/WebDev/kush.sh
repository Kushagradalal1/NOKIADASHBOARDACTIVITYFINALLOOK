#!/bin/bash

# Set the dynamic data
date1="2023-04-19"
time1="16:23"
utilization1="158G"
workspace1="/var/fpwork/a21114"

date2="2023-04-24"
time2="14:47"
utilization2="162G"
workspace2="/var/fpwork/docker"

date3="2023-02-03"
time3="18:16"
utilization3="4.0K"
workspace3="/var/fpwork/magdum"

date4="2021-11-28"
time4="18:02"
utilization4="821M"
workspace4="/var/fpwork/pks"

date5="2023-04-24"
time5="14:47"
utilization5="217G"
workspace5="/var/fpwork/shamahma"

date6="2023-04-01"
time6="18:31"
utilization6="224G"
workspace6="/var/fpwork/ssai"

date7="2023-04-24"
time7="15:44"
utilization7="134G"
workspace7="/var/fpwork/sshrimat"

date8="2023-04-24"
time8="15:44"
utilization8="894G"
workspace8="total"

# Create an associative array to store the dynamic data
declare -A data
data=("date1" "$date1" "time1" "$time1" "utilization1" "$utilization1" "workspace1" "$workspace1" \
      "date2" "$date2" "time2" "$time2" "utilization2" "$utilization2" "workspace2" "$workspace2" \
      "date3" "$date3" "time3" "$time3" "utilization3" "$utilization3" "workspace3" "$workspace3" \
      "date4" "$date4" "time4" "$time4" "utilization4" "$utilization4" "workspace4" "$workspace4" \
      "date5" "$date5" "time5" "$time5" "utilization5" "$utilization5" "workspace5" "$workspace5" \
      "date6" "$date6" "time6" "$time6" "utilization6" "$utilization6" "workspace6" "$workspace6" \
      "date7" "$date7" "time7" "$time7" "utilization7" "$utilization7" "workspace7" "$workspace7" \
      "date8" "$date8" "time8" "$time8" "utilization8" "$utilization8" "workspace8" "$workspace8")

# Convert associative array to JSON format
json="{"
for key in "${!data[@]}"; do
  json+="\"$key\":\"${data[$key]}\","
done
json="${json%,}}"
echo "$json"
