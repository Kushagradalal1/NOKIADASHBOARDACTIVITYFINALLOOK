let sectionCount = 0;

function addSection() {
  const sectionsContainer = document.getElementById('sections-container');

  const section = document.createElement('div');
  section.classList.add('section');
  section.id = `section-${sectionCount}`;

  const imageInput = document.createElement('input');
  imageInput.type = 'file';
  imageInput.accept = 'image/*';
  imageInput.addEventListener('change', handleImageUpload);

  const textInput = document.createElement('input');
  textInput.type = 'text';
  textInput.placeholder = 'Enter text';

  const deleteButton = document.createElement('span');
  deleteButton.classList.add('delete-button');
  deleteButton.textContent = 'Delete';
  deleteButton.addEventListener('click', () => deleteSection(section.id));

  section.appendChild(imageInput);
  section.appendChild(textInput);
  section.appendChild(deleteButton);

  sectionsContainer.appendChild(section);

  sectionCount++;
}

function handleImageUpload(event) {
  const sectionId = event.target.parentNode.id;
  const section = document.getElementById(sectionId);
  const imageFile = event.target.files[0];

  const reader = new FileReader();
  reader.onload = function (e) {
    const imagePreview = document.createElement('img');
    imagePreview.src = e.target.result;
    imagePreview.classList.add('section-image');

    if (section.getElementsByClassName('section-image').length > 0) {
      section.replaceChild(imagePreview, section.getElementsByClassName('section-image')[0]);
    } else {
      section.insertBefore(imagePreview, section.childNodes[0]);
    }
  };
  reader.readAsDataURL(imageFile);
}

function deleteSection(sectionId) {
  const section = document.getElementById(sectionId);
  section.parentNode.removeChild(section);
}
