const axios = require('axios');

const fetchFreeAPIs = async () => {
  try {
    const response = await axios.get('https://api.publicapis.org/entries');
    const { data } = response;
    return data;
  } catch (error) {
    console.error(error);
  }
};

// Example usage
fetchFreeAPIs()
  .then((data) => console.log(data))
  .catch((error) => console.error(error));
