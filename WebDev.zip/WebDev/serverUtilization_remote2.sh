#!/bin/bash
#set -x

# Define the remote servers
#SERVERS=("10.131.233.18" "10.131.233.19")
#SERVERS=("10.131.233.18" "10.131.233.19" "10.159.236.36")
SERVERS=("10.135.150.156" "10.135.150.42" "10.159.236.16" "10.159.236.36" "10.159.236.69" "10.159.236.87" "10.159.236.88" "10.159.252.12" "10.159.252.19" "10.159.252.5" "10.159.252.5" "10.159.236.5") 

# Define the output file
OUTPUT_FILE="report.html"
#OUTPUT_FILE1="report1.html"

# Define the HTML header
echo "<html>" > $OUTPUT_FILE
echo "<head>" >> $OUTPUT_FILE
echo "<title>Server Utilization Report</title>" >> $OUTPUT_FILE
echo "</head>" >> $OUTPUT_FILE
echo "<body>" >> $OUTPUT_FILE

###############
echo '<HTML><HEAD><TITLE>STATS</TITLE></HEAD><BODY>' >> $OUTPUT_FILE
  echo '<H3>'$(uname -n)'</H3><TABLE BORDER=3 CELLSPACING=0 CELLPADDING=2>' >> $OUTPUT_FILE
#  echo '<TR><TH>Date</TH><TH>Time</TH>' >> $OUTPUT_FILE
#  echo '<TH>Utilization</TH><TH>WorkSpace</TH></TR>' >> $OUTPUT_FILE
  echo '</TABLE><P>Generated at '$(date '+%H:%M on %d-%b-%y')' for '$(hostname -s)'</BODY></HTML>' >> $OUTPUT_FILE
################
# Generate the HTML table structure
echo "<table>" >> $OUTPUT_FILE
echo "<thead>" >> $OUTPUT_FILE
echo "<tr>" >> $OUTPUT_FILE
echo "<th>Server Name</th>" >> $OUTPUT_FILE
echo "<th>Total CPU</th>" >> $OUTPUT_FILE
echo "<th>CPU Utilization</th>" >> $OUTPUT_FILE
echo "<th>Total Memory</th>" >> $OUTPUT_FILE
echo "<th>Memory Utilization</th>" >> $OUTPUT_FILE
echo "<th>Memory Still Free</th>" >> $OUTPUT_FILE
echo "<th>Active Sessions</th>" >> $OUTPUT_FILE
echo "<th>User Logins</th>" >> $OUTPUT_FILE
echo "<th>Date & Time</th>" >> $OUTPUT_FILE
echo "<th>Workspace</th>" >> $OUTPUT_FILE
echo "<th>Disk Util</th>" >> $OUTPUT_FILE
echo "</tr>" >> $OUTPUT_FILE
echo "</thead>" >> $OUTPUT_FILE
echo "<tbody>" >> $OUTPUT_FILE

# Loop through each server
for SERVER in "${SERVERS[@]}"
do
  # Get the Total CPU Available
  TotalCPU=$(ssh $SERVER "nproc")

  # Get the CPU utilization
  CPU=$(ssh $SERVER "top -bn1 | grep 'Cpu(s)' | awk '{print \$2}'")

  # Get the Total Memory available
  TotalMem=$(ssh $SERVER 'free -h'| awk '/Mem/{x[1]=$2} END{print x[1],x[2]}')

  # Get the memory utilization
  MEMORY=$(ssh $SERVER "free -m | awk 'NR==2{printf \"%.2f%%\", \$3*100/\$2}'")

  # Get the memory still Free
  FreeMem=$(ssh $SERVER 'free -h;nproc' | awk '/Mem/ { print $7 }')

  # Get the number of active sessions
  SESSIONS=$(ssh $SERVER "who | wc -l")

  # Get the memory still Free
  FreeMem=$(ssh $SERVER 'free -h;nproc' | awk '/Mem/ { print $7 }')

  # Get the Date and Time for Hostname
 # Datetime=$(ssh $SERVER "echo $(date '+%H:%M on %d-%b-%y') for '$(hostname -s)'")
  Datetime=$(ssh $SERVER 'echo "$(hostname -s)" $(date '+%c')')
echo $Datetime

  # Get the Date and Time for Hostname
Workspace=$(ssh $SERVER "find /var/fpwork/* -maxdepth 1 -type d ! -path . -exec du -chs --time {} + |grep -v "lost+found" ")

Disk=$(ssh $SERVER "df -h /var/fpwork|awk 'NR==2{printf \"%s is already used out of %dGB/%dGB\", \$5,\$3,\$2}' ")
echo $Disk
#"echo $(df -h /var/fpwork|awk 'NR==2{printf "%s %dGB/%dGB\n",$5,$3,$2}') $(hostname) $vol"

  # Define the color based on CPU utilization
  if (( $(echo "$CPU > 80.0" | bc -l) )); then
    COLOR="red"
  elif (( $(echo "$CPU > 60.0" | bc -l) )); then
    COLOR="orange"
  else
   # COLOR="green"
    COLOR="orange"
  fi

##########
# Define the color based on MEMORY utilization
#  if (( $(echo "$MEMORY > 0" | bc -l) )); then
#    COLOR="red"
#  elif (( $(echo "$MEMORY > 0" | bc -l) )); then
#    COLOR="orange"
#  else
#    COLOR="blue"
#  fi
#############################
####################################333333333333333333333333##########################
 find /var/fpwork/* -maxdepth 1 -type d ! -path . -exec du -chs --time {} + |grep -v "lost+found"|while read PERC FS SIZE MOUNT
  do
#    PERCENT=${PERC%%%}
    if [[ $PERCENT -gt 30 ]]
    then
         COLOR=red
    else
         COLOR=blue
    fi
    echo '<TR><TD>'$FS'</TD><TD ALIGN=RIGHT>'$SIZE'</TD> '
    echo '<TD><TABLE BORDER=0 CELLSPACING=1 CELLPADDING=0><TR>'
    echo '<TD><FONT SIZE=-1 COLOR="'$COLOR'"> '$PERC'</FONT></TD>'
    echo '<TR></TABLE></TD><TD>'$MOUNT'</TD></TR>'
  done
################################3333333333333333333333333333333333
####################################
#UserLogin=$(for user in $(lastlog -b 0 -t 15 | awk '{print $1}' | grep -v "Username\|eemon\|ps_unx*\|root\|wtmp\|cmdbdis"); do last -R -F -n 1 anandukh |awk '{print $1 "  " $4 " " $5 "  " $6 "  " $7 "  " $8  " " $10 " " $11 " " $12 " " $13}' |grep -v wtmp; done)
#UerLogin=$(ssh $SERVER "last -R -F -n 10|awk '{print $1 "  " $4 " " $5 "  " $6 "  " $7 "  " $8  " " $10 " " $11 " " $12 " " $13}' |grep -v 'cmdbdis\|ps_unx*\|wtmp'")
UserLogin=$(ssh $SERVER "lastlog -b 0 -t 15 |grep -v 'Username\|eemon\|ps_unx*\|root\|cmdbdis\|gdm\|uvmuser\|cmdbdis\|ps_unx*\|wtmp' |awk '{print \$1}'")
echo $UserLogin
#UserLogin=$(ssh $SERVER "lastlog -b 0 -t 15 |grep -v 'Username\|eemon\|ps_unx*\|root\|cmdbdis\|gdm\|uvmuser' |awk '{print "\$1" " ' ' " "\$5" "\ " "\$6"}' ")
#echo $UserLogin
#UserLogin=$(ssh $SERVER "lastlog -b 0 -t 15 |grep -v 'Username\|eemon\|ps_unx*\|root\|cmdbdis\|gdm\|uvmuser' |awk -v OFS='\t' '{print $6, $5, $9, $1}'  ")
#echo $UserLogin
UserLogin=$(ssh $SERVER "lastlog -b 0 -t 15" |grep -v 'Username\|eemon\|ps_unx*\|root\|cmdbdis\|gdm\|uvmuser\|cmdbdis\|ps_unx*\|wtmp' | awk -v OFS='\t' '{print $6, $5, $9, $1}' )
echo $UserLogin
#echo "User Login Report for last 15 days"
#echo "----------------------------------------------"
#echo "Username |From Date Time      |To Date  Time  "
#echo "----------------------------------------------"


#echo "-----------------------------------"
#################################################################
  # Generate the HTML table row
  echo "<tr>" >> $OUTPUT_FILE
#  echo "<td>$SERVER</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$SERVER</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$TotalCPU</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$CPU</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$TotalMem</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$MEMORY</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$FreeMem</td>" >> $OUTPUT_FILE
 # echo "<td>$MEMORY</td>" >> $OUTPUT_FILE
 # echo "<td>$SESSIONS</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$SESSIONS</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$UserLogin</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$Datetime</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$Workspace</td>" >> $OUTPUT_FILE
  echo "<td style='background-color:$COLOR;'>$Disk</td>" >> $OUTPUT_FILE
  echo "</tr>" >> $OUTPUT_FILE
done

# Close the HTML table structure
echo "</tbody>" >> $OUTPUT_FILE
echo "</table>" >> $OUTPUT_FILE

# Define the HTML footer
echo "</body>" >> $OUTPUT_FILE
echo "</html>" >> $OUTPUT_FILE

